
from load_dataset import find_separate_organ_bboxes

if __name__=='__main__':
    find_separate_organ_bboxes.GetOrganBBoxes()